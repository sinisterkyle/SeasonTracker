package com.seasontracker;

import net.minecraftforge.common.ForgeConfigSpec;

/** config/seasontracker-common.toml (this is the one that matters on the server). */
public final class CommonConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.BooleanValue NIGHT_STARTS_NEXT_DAY;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.push("dayCounter");
        NIGHT_STARTS_NEXT_DAY = b.comment(
                        "When the day number goes up.",
                        "true:  at nightfall -> DAY 3,320, NIGHT 3,321, DAY 3,321, NIGHT 3,322 ...",
                        "false: at sunrise   -> DAY 3,320, NIGHT 3,320, DAY 3,321, NIGHT 3,321 ...",
                        "Changing this later doesn't rewrite the saved count; use /seasontracker setday if needed.")
                .define("nightStartsNextDay", true);
        b.pop();
        SPEC = b.build();
    }

    private CommonConfig() {}
}
