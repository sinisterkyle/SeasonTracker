package com.seasontracker;

import net.minecraftforge.common.ForgeConfigSpec;

/** config/seasontracker-client.toml */
public final class ClientConfig {
    public static final ForgeConfigSpec SPEC;

    public static final ForgeConfigSpec.BooleanValue ENABLED;
    public static final ForgeConfigSpec.BooleanValue SHOW_SUB_SEASON;
    public static final ForgeConfigSpec.ConfigValue<String> AUTUMN_NAME;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.push("hud");
        ENABLED = b.comment("Show the tracker line under Xaero's Minimap.")
                .define("enabled", true);
        SHOW_SUB_SEASON = b.comment("Show EARLY/MID/LATE too, e.g. [LATE FALL].")
                .define("showSubSeason", false);
        AUTUMN_NAME = b.comment("Label used for autumn.")
                .define("autumnName", "FALL");
        b.pop();
        SPEC = b.build();
    }

    private ClientConfig() {}
}
