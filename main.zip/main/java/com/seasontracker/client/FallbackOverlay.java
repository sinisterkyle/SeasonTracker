package com.seasontracker.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraftforge.client.gui.overlay.ForgeGui;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * Safety net only: if a future Xaero update changes its info-display internals and the hook
 * fails, the line is drawn as a small box directly under the minimap (above it if the map sits at
 * the bottom of the screen). If even the minimap's position can't be read, it uses the top-right corner.
 * While the Xaero hook works, this returns on its first line.
 */
public final class FallbackOverlay {
    private static Component lastLine;
    private static int lastWidth;

    // Reflection into Xaero: BuiltInHudModules.MINIMAP -> getPushState() -> x, y, w, h (GUI pixels)
    private static boolean lookedUp;
    private static long retryAt;
    private static Object minimapModule;
    private static Method getPushState, getCurrentSession, isActive, isFlippedVer;
    private static Field fx, fy, fw, fh;

    public static void render(ForgeGui gui, GuiGraphics g, float partialTick, int screenWidth, int screenHeight) {
        if (!XaeroBridge.hasFailed()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.options.hideGui || mc.options.renderDebug) return;

        Component line = SeasonLine.get();
        if (line == null) return;
        if (line != lastLine) {
            lastLine = line;
            lastWidth = mc.font.width(line);
        }
        int lh = mc.font.lineHeight;

        // Default: top-right corner.
        int x = screenWidth - lastWidth - 6;
        int y = 4;

        int[] map = minimapRect();
        if (map != null) {
            x = map[0] + (map[2] - lastWidth) / 2;               // centred on the map
            y = map[4] == 1 ? map[1] - lh - 3 : map[1] + map[3] + 4; // above if the map is at the bottom
            x = Math.max(2, Math.min(x, screenWidth - lastWidth - 2));
            y = Math.max(2, Math.min(y, screenHeight - lh - 2));
        }

        g.fill(x - 2, y - 2, x + lastWidth + 2, y + lh, 0x90000000);
        g.drawString(mc.font, line, x, y, 0xFFFFFF, true);
    }

    /** {x, y, w, h, flippedVertically(0/1)} of Xaero's minimap on screen, or null if unknown/hidden. */
    private static int[] minimapRect() {
        if (System.currentTimeMillis() < retryAt) return null;
        try {
            if (!lookedUp) {
                lookedUp = true;
                Class<?> modules = Class.forName("xaero.hud.minimap.BuiltInHudModules");
                minimapModule = modules.getField("MINIMAP").get(null);
                Class<?> moduleCls = Class.forName("xaero.hud.module.HudModule");
                getPushState = moduleCls.getMethod("getPushState");
                getCurrentSession = moduleCls.getMethod("getCurrentSession");
                Class<?> sessionCls = Class.forName("xaero.hud.module.ModuleSession");
                isActive = sessionCls.getMethod("isActive");
                isFlippedVer = sessionCls.getMethod("isFlippedVer");
                Class<?> stateCls = Class.forName("xaero.hud.pushbox.PushboxHandler$State");
                fx = stateCls.getField("x");
                fy = stateCls.getField("y");
                fw = stateCls.getField("w");
                fh = stateCls.getField("h");
            }
            if (minimapModule == null) return null;
            Object session = getCurrentSession.invoke(minimapModule);
            if (session == null || !Boolean.TRUE.equals(isActive.invoke(session))) return null;
            Object st = getPushState.invoke(minimapModule);
            if (st == null) return null;
            int w = fw.getInt(st), h = fh.getInt(st);
            if (w <= 0 || h <= 0) return null;
            boolean flipped = Boolean.TRUE.equals(isFlippedVer.invoke(session));
            return new int[]{fx.getInt(st), fy.getInt(st), w, h, flipped ? 1 : 0};
        } catch (Throwable t) {
            retryAt = System.currentTimeMillis() + 2000; // try again shortly instead of giving up for good
            lookedUp = false;
            return null;
        }
    }

    private FallbackOverlay() {}
}
