package com.seasontracker.client;

import com.seasontracker.ClientConfig;
import com.seasontracker.ClientDayState;
import com.seasontracker.network.Network;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

import java.util.Locale;
import java.util.Objects;

/**
 * Builds the line  ☀ DAY 3,320 [FALL]  /  ☽ NIGHT 3,321 [FALL].
 *
 * Lightweight: does at most one tiny check per game tick, asks Serene Seasons once per second,
 * and only rebuilds the text when day/night, the number or the season actually changes.
 * Every render frame in between just returns the cached Component.
 */
public final class SeasonLine {
    private static final String SUN = "☀";   // ☀
    private static final String MOON = "☽";  // ☽
    private static final int SUN_COLOR = 0xFFD84A;
    private static final int MOON_COLOR = 0xB4C8FF;
    private static final int TEXT_COLOR = 0xFFFFFF;
    private static final int SEASON_CHECK_TICKS = 20;

    private static ClientLevel level;
    private static long lastGameTime = Long.MIN_VALUE;
    private static int seasonCheckIn;

    private static boolean night;
    private static long day = -1;
    private static String seasonLabel;
    private static int seasonColor;
    private static Component cached;

    public static Component get() {
        if (!ClientConfig.ENABLED.get()) return null;
        ClientLevel lvl = Minecraft.getInstance().level;
        if (lvl == null) {
            level = null;
            cached = null;
            return null;
        }
        long gameTime = lvl.getGameTime();
        if (lvl == level && gameTime == lastGameTime) return cached;   // same tick: reuse
        if (lvl != level) {
            level = lvl;
            seasonCheckIn = 0;
        }
        lastGameTime = gameTime;

        long dayTime = lvl.getDayTime();
        long t = Math.floorMod(dayTime, 24000L);
        boolean newNight = t >= 13000L && t < 23000L;
        long newDay = dayNumber(dayTime);

        String newLabel = seasonLabel;
        int newColor = seasonColor;
        if (--seasonCheckIn <= 0) {
            seasonCheckIn = SEASON_CHECK_TICKS;
            SeasonsBridge.SeasonInfo info = SeasonsBridge.get(lvl);
            newLabel = info == null ? null : label(info);
            newColor = info == null ? TEXT_COLOR : color(info.season());
        }

        if (cached == null || newNight != night || newDay != day
                || !Objects.equals(newLabel, seasonLabel) || newColor != seasonColor) {
            night = newNight;
            day = newDay;
            seasonLabel = newLabel;
            seasonColor = newColor;
            cached = newDay < 0 ? null : build();
        }
        return cached;
    }

    /** World day count from the server; -1 = not received yet (line hidden). */
    private static long dayNumber(long dayTime) {
        if (ClientDayState.isKnown()) return ClientDayState.get();
        ClientPacketListener connection = Minecraft.getInstance().getConnection();
        if (connection != null && Network.hasMod(connection.getConnection())) return -1;
        // Server without Season Tracker: work it out from the world clock (+1 at nightfall).
        return Math.floorDiv(dayTime + 11000L, 24000L) + 1L;
    }

    private static Component build() {
        final boolean n = night;
        MutableComponent line = Component.literal(n ? MOON : SUN)
                .withStyle(s -> s.withColor(n ? MOON_COLOR : SUN_COLOR));
        line.append(Component.literal((n ? " NIGHT " : " DAY ") + String.format(Locale.US, "%,d", day))
                .withStyle(s -> s.withColor(TEXT_COLOR)));
        if (seasonLabel != null) {
            final int c = seasonColor;
            line.append(Component.literal(" [" + seasonLabel + "]").withStyle(s -> s.withColor(c)));
        }
        return line;
    }

    private static String label(SeasonsBridge.SeasonInfo info) {
        String name = "AUTUMN".equals(info.season())
                ? ClientConfig.AUTUMN_NAME.get().toUpperCase(Locale.ROOT)
                : info.season();
        if (ClientConfig.SHOW_SUB_SEASON.get() && info.subSeason() != null) {
            int idx = info.subSeason().indexOf('_');
            if (idx > 0) name = info.subSeason().substring(0, idx) + " " + name; // EARLY / MID / LATE
        }
        return name;
    }

    private static int color(String season) {
        return switch (season) {
            case "SPRING" -> 0x7CFC6A;
            case "SUMMER" -> 0xFFD23F;
            case "AUTUMN" -> 0xFF8C2E;
            case "WINTER" -> 0x9FE6FF;
            default -> TEXT_COLOR;
        };
    }

    private SeasonLine() {}
}
