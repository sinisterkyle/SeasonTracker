package com.seasontracker.client;

import com.seasontracker.ClientDayState;
import net.minecraft.client.Minecraft;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.IEventBus;

public final class ClientSetup {
    private static int tickCounter;

    public static void init(IEventBus modBus) {
        modBus.addListener(ClientSetup::registerOverlays);
        MinecraftForge.EVENT_BUS.addListener(ClientSetup::onClientTick);
        MinecraftForge.EVENT_BUS.addListener(ClientSetup::onLoggingOut);
    }

    private static void registerOverlays(RegisterGuiOverlaysEvent event) {
        event.registerAboveAll("season_tracker", FallbackOverlay::render);
    }

    private static void onClientTick(TickEvent.ClientTickEvent event) {
        // Only runs until the Xaero hook is in place (normally the first second in a world), then does nothing.
        if (event.phase != TickEvent.Phase.END || XaeroBridge.isDone()) return;
        if (Minecraft.getInstance().level != null && ++tickCounter % 20 == 0) {
            XaeroBridge.tryRegister();
        }
    }

    private static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
        ClientDayState.clear();
    }

    private ClientSetup() {}
}
