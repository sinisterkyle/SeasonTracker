package com.seasontracker.client;

import com.seasontracker.SeasonTracker;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;
import net.minecraftforge.fml.ModList;

import java.lang.reflect.Method;

/**
 * Reads the current season from Serene Seasons' public API via reflection,
 * so this mod compiles without Serene Seasons on the classpath.
 *
 * Equivalent to: SeasonHelper.getSeasonState(level).getSeason() / getSubSeason()
 */
public final class SeasonsBridge {
    private static boolean initialised;
    private static Method getSeasonState;
    private static Method getSeason;
    private static Method getSubSeason;
    private static Method isDimensionWhitelisted;

    /** Season info, or null if Serene Seasons is missing / this dimension has no seasons. */
    public record SeasonInfo(String season, String subSeason) {}

    public static SeasonInfo get(Level level) {
        init();
        if (getSeasonState == null || level == null) return null;
        try {
            if (isDimensionWhitelisted != null) {
                try {
                    Object ok = isDimensionWhitelisted.invoke(null, level.dimension());
                    if (Boolean.FALSE.equals(ok)) return null;
                } catch (Throwable ignored) {
                    // server config not synced yet: assume seasons are on
                }
            }
            Object state = getSeasonState.invoke(null, level);
            if (state == null) return null;
            Enum<?> season = (Enum<?>) getSeason.invoke(state);      // SPRING, SUMMER, AUTUMN, WINTER
            Enum<?> sub = (Enum<?>) getSubSeason.invoke(state);      // EARLY_AUTUMN, MID_AUTUMN, ...
            if (season == null) return null;
            return new SeasonInfo(season.name(), sub == null ? null : sub.name());
        } catch (Throwable t) {
            return null;
        }
    }

    private static void init() {
        if (initialised) return;
        initialised = true;
        if (!ModList.get().isLoaded("sereneseasons")) return;
        try {
            Class<?> helper = Class.forName("sereneseasons.api.season.SeasonHelper");
            Class<?> stateCls = Class.forName("sereneseasons.api.season.ISeasonState");
            getSeasonState = helper.getMethod("getSeasonState", Level.class);
            getSeason = stateCls.getMethod("getSeason");
            getSubSeason = stateCls.getMethod("getSubSeason");
            try {
                Class<?> cfg = Class.forName("sereneseasons.config.ServerConfig");
                isDimensionWhitelisted = cfg.getMethod("isDimensionWhitelisted", ResourceKey.class);
            } catch (Throwable ignored) {
                isDimensionWhitelisted = null;
            }
        } catch (Throwable t) {
            getSeasonState = null;
            SeasonTracker.LOGGER.warn("[SeasonTracker] Serene Seasons found but its API could not be read", t);
        }
    }

    private SeasonsBridge() {}
}
