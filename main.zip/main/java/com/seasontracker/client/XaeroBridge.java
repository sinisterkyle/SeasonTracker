package com.seasontracker.client;

import com.seasontracker.SeasonTracker;
import net.minecraft.network.chat.Component;
import net.minecraftforge.fml.ModList;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.List;

/**
 * Adds a "Season Tracker" entry to Xaero's Minimap info display list (the lines drawn
 * directly under the minimap: coordinates, biome, time, ...). Because it is one of Xaero's
 * own lines, it follows the minimap wherever you move it in Xaero's HUD editor, and it can be
 * toggled / reordered in Xaero's settings -> Info Display.
 *
 * Done via reflection against Xaero's Minimap 25.x and 26.x (xaero.hud.minimap.info.*), so this mod
 * builds without Xaero on the classpath, and falls back to a small box under the minimap if a future
 * Xaero version changes these internals. It runs once; after that Xaero just calls our
 * compiler, which returns the cached line.
 */
public final class XaeroBridge {
    public static final String DISPLAY_ID = SeasonTracker.MODID;

    private static final int MAX_ATTEMPTS = 60; // tried once a second in-world: ~1 minute, then give up

    private static boolean registered;
    private static boolean failed;
    private static int attempts;
    private static Throwable lastError;

    public static boolean isActive() {
        return registered;
    }

    /** Hook gave up (incompatible Xaero version); the fallback overlay takes over. */
    public static boolean hasFailed() {
        return failed;
    }

    /** Nothing left to try. */
    public static boolean isDone() {
        return registered || failed;
    }

    public static void tryRegister() {
        if (registered || failed) return;
        if (!ModList.get().isLoaded("xaerominimap")) {
            failed = true;
            return;
        }
        if (++attempts > MAX_ATTEMPTS) {
            failed = true;
            SeasonTracker.LOGGER.warn("[SeasonTracker] Couldn't add the line to Xaero's Minimap {} after {} tries; "
                    + "drawing it as a box under the minimap instead.", xaeroVersion(), MAX_ATTEMPTS, lastError);
            return;
        }

        try {
            // HudMod.INSTANCE.getMinimap().getInfoDisplays().getManager()
            Class<?> hudModCls = Class.forName("xaero.common.HudMod");
            Object hudMod = hudModCls.getField("INSTANCE").get(null);
            if (hudMod == null) return;
            // Wait until Xaero has finished loading its client side (settings, info displays...).
            try {
                if (!Boolean.TRUE.equals(hudModCls.getMethod("isLoadedClient").invoke(hudMod))) return;
            } catch (NoSuchMethodException ignored) {
                // older Xaero without this method
            }
            Object minimap = hudModCls.getMethod("getMinimap").invoke(hudMod);
            if (minimap == null) return;
            Object infoDisplays = minimap.getClass().getMethod("getInfoDisplays").invoke(minimap);
            if (infoDisplays == null) return;
            Object manager = infoDisplays.getClass().getMethod("getManager").invoke(infoDisplays);
            if (manager == null) return;

            Class<?> managerCls = Class.forName("xaero.hud.minimap.info.InfoDisplayManager");
            Class<?> displayCls = Class.forName("xaero.hud.minimap.info.InfoDisplay");
            Class<?> builderCls = Class.forName("xaero.hud.minimap.info.InfoDisplay$Builder");
            Class<?> codecCls = Class.forName("xaero.hud.minimap.info.codec.InfoDisplayStateCodec");
            Class<?> widgetCls = Class.forName("xaero.hud.minimap.info.widget.InfoDisplayWidgetFactory");
            Class<?> onCompileCls = Class.forName("xaero.hud.minimap.info.render.compile.InfoDisplayOnCompile");
            Class<?> compilerCls = Class.forName("xaero.hud.minimap.info.render.compile.InfoDisplayCompiler");

            // Already there (e.g. after rejoining a world)?
            if (managerCls.getMethod("get", String.class).invoke(manager, DISPLAY_ID) != null) {
                applyOrder(managerCls, manager);
                registered = true;
                return;
            }

            Object booleanCodec = Class.forName("xaero.hud.minimap.info.codec.InfoDisplayCommonStateCodecs")
                    .getField("BOOLEAN").get(null);
            Object offOnWidget = Class.forName("xaero.hud.minimap.info.widget.InfoDisplayCommonWidgetFactories")
                    .getField("OFF_ON").get(null);

            Method getState = displayCls.getMethod("getState");
            Method addLine = compilerCls.getMethod("addLine", Component.class);

            // InfoDisplayOnCompile<Boolean>:
            //   onCompile(InfoDisplay display, InfoDisplayCompiler compiler, MinimapSession session, int size, BlockPos pos)
            Object onCompile = Proxy.newProxyInstance(
                    onCompileCls.getClassLoader(),
                    new Class<?>[]{onCompileCls},
                    (proxy, method, args) -> {
                        switch (method.getName()) {
                            case "onCompile" -> {
                                if (!Boolean.TRUE.equals(getState.invoke(args[0]))) return null;
                                Component line = SeasonLine.get();
                                if (line != null) addLine.invoke(args[1], line);
                                return null;
                            }
                            case "hashCode" -> { return System.identityHashCode(proxy); }
                            case "equals" -> { return proxy == args[0]; }
                            case "toString" -> { return "SeasonTrackerInfoDisplayCompiler"; }
                            default -> { return null; }
                        }
                    });

            Object b = builderCls.getMethod("begin").invoke(null);
            builderCls.getMethod("setId", String.class).invoke(b, DISPLAY_ID);
            builderCls.getMethod("setName", Component.class).invoke(b, Component.translatable("seasontracker.infodisplay"));
            builderCls.getMethod("setDefaultState", Object.class).invoke(b, Boolean.TRUE);
            builderCls.getMethod("setCodec", codecCls).invoke(b, booleanCodec);
            builderCls.getMethod("setWidgetFactory", widgetCls).invoke(b, offOnWidget);
            builderCls.getMethod("setCompiler", onCompileCls).invoke(b, onCompile);
            Object display = builderCls.getMethod("build").invoke(b);

            managerCls.getMethod("add", displayCls).invoke(manager, display);

            // Xaero already built its line order before we registered, so rebuild it to include us.
            applyOrder(managerCls, manager);

            registered = true;
            SeasonTracker.LOGGER.info("[SeasonTracker] Added the tracker line under Xaero's Minimap {} (try {}).",
                    xaeroVersion(), attempts);
        } catch (Throwable t) {
            // Don't give up on the first error: Xaero may still be loading (slower PCs, big modpacks).
            // tryRegister() runs again in a second; a half-finished registration is completed then.
            lastError = t;
        }
    }

    private static String xaeroVersion() {
        try {
            return ModList.get().getModContainerById("xaerominimap")
                    .map(c -> c.getModInfo().getVersion().toString()).orElse("?");
        } catch (Throwable t) {
            return "?";
        }
    }

    /**
     * Rebuilds Xaero's line order so our new line is included.
     *  - Xaero 25.x: setOrder(currentOrder) re-inserts missing defaults (ours).
     *  - Xaero 26.x: setOrder is gone; applyLocalConfig() rebuilds the order from the config,
     *    adding defaults it doesn't know about (ours).
     */
    private static void applyOrder(Class<?> managerCls, Object manager) throws Exception {
        try {
            Method setOrder = managerCls.getMethod("setOrder", List.class);
            List<String> order = currentOrder(managerCls, manager);
            if (order != null) setOrder.invoke(manager, order);
            return;
        } catch (NoSuchMethodException ignored) {
            // newer Xaero
        }
        managerCls.getMethod("applyLocalConfig").invoke(manager);
    }

    @SuppressWarnings("unchecked")
    private static List<String> currentOrder(Class<?> managerCls, Object manager) {
        // Preferred: the private 'order' list (keeps ids of displays from other mods that aren't loaded yet).
        try {
            Field f = managerCls.getDeclaredField("order");
            f.setAccessible(true);
            Object o = f.get(manager);
            if (o == null) return null;
            return new ArrayList<>((List<String>) o);
        } catch (Throwable ignored) {
        }
        // Fallback: ids of the currently ordered displays.
        try {
            Method getId = Class.forName("xaero.hud.minimap.info.InfoDisplay").getMethod("getId");
            java.util.stream.Stream<?> stream =
                    (java.util.stream.Stream<?>) managerCls.getMethod("getOrderedStream").invoke(manager);
            List<String> ids = new ArrayList<>();
            java.util.Iterator<?> it = stream.iterator();
            while (it.hasNext()) {
                ids.add((String) getId.invoke(it.next()));
            }
            return ids;
        } catch (Throwable ignored) {
            return null;
        }
    }

    private XaeroBridge() {}
}
