package com.seasontracker;

import com.mojang.logging.LogUtils;
import com.seasontracker.client.ClientSetup;
import com.seasontracker.network.Network;
import com.seasontracker.server.DayCounter;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.fml.loading.FMLEnvironment;
import org.slf4j.Logger;

@Mod(SeasonTracker.MODID)
public class SeasonTracker {
    public static final String MODID = "seasontracker";
    public static final Logger LOGGER = LogUtils.getLogger();

    public SeasonTracker() {
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, CommonConfig.SPEC);
        ModLoadingContext.get().registerConfig(ModConfig.Type.CLIENT, ClientConfig.SPEC);

        // Both sides: packet that carries the day count from server to client.
        Network.register();

        // Server side (dedicated server AND the integrated server in singleplayer):
        // tracks the day count in the world save.
        MinecraftForge.EVENT_BUS.register(DayCounter.class);

        // Client side: the HUD.
        if (FMLEnvironment.dist == Dist.CLIENT) {
            ClientSetup.init(FMLJavaModLoadingContext.get().getModEventBus());
        }
    }
}
