package com.seasontracker;

/**
 * The day count last sent by the server. Plain static holder (no client-only imports),
 * so the network handler can touch it safely on either side.
 */
public final class ClientDayState {
    private static volatile boolean known;
    private static volatile long dayCount;

    public static void set(long count) {
        dayCount = count;
        known = true;
    }

    public static boolean isKnown() {
        return known;
    }

    public static long get() {
        return dayCount;
    }

    public static void clear() {
        known = false;
        dayCount = 0;
    }

    private ClientDayState() {}
}
