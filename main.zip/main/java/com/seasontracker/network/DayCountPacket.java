package com.seasontracker.network;

import com.seasontracker.ClientDayState;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Server -> client: the current world day count. */
public record DayCountPacket(long dayCount) {

    public void encode(FriendlyByteBuf buf) {
        buf.writeLong(dayCount);
    }

    public static DayCountPacket decode(FriendlyByteBuf buf) {
        return new DayCountPacket(buf.readLong());
    }

    public static void handle(DayCountPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ClientDayState.set(msg.dayCount());
    }
}
