package com.seasontracker.network;

import com.seasontracker.SeasonTracker;
import net.minecraft.network.Connection;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

public final class Network {
    private static final String VERSION = "1";

    // acceptMissingOr: players without the mod can still join a server that has it (and vice versa).
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(SeasonTracker.MODID, "main"),
            () -> VERSION,
            NetworkRegistry.acceptMissingOr(VERSION),
            NetworkRegistry.acceptMissingOr(VERSION));

    public static void register() {
        CHANNEL.messageBuilder(DayCountPacket.class, 0, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(DayCountPacket::encode)
                .decoder(DayCountPacket::decode)
                .consumerMainThread(DayCountPacket::handle)
                .add();
    }

    /** True if the other end of this connection has Season Tracker installed. */
    public static boolean hasMod(Connection connection) {
        return connection != null && CHANNEL.isRemotePresent(connection);
    }

    public static void sendTo(ServerPlayer player, long dayCount) {
        if (hasMod(player.connection.connection)) {
            CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new DayCountPacket(dayCount));
        }
    }

    public static void sendToAll(MinecraftServer server, long dayCount) {
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            sendTo(player, dayCount);
        }
    }

    private Network() {}
}
