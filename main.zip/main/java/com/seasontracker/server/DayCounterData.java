package com.seasontracker.server;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

/** Saved in <world>/data/seasontracker_days.dat, so it survives restarts and travels with the world. */
public class DayCounterData extends SavedData {
    private static final String NAME = "seasontracker_days";
    /** v1 started from the resettable day clock; v2 starts from the world's total age. */
    private static final int VERSION = 2;

    boolean initialised;
    long dayCount;
    long lastDayTime;

    public static DayCounterData get(ServerLevel overworld) {
        return overworld.getDataStorage().computeIfAbsent(DayCounterData::load, DayCounterData::new, NAME);
    }

    private static DayCounterData load(CompoundTag tag) {
        DayCounterData d = new DayCounterData();
        d.dayCount = tag.getLong("DayCount");
        d.lastDayTime = tag.getLong("LastDayTime");
        // Files from the first version (no Version tag) get recalculated once from the world's age.
        d.initialised = tag.getInt("Version") >= VERSION;
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        tag.putLong("DayCount", dayCount);
        tag.putLong("LastDayTime", lastDayTime);
        tag.putInt("Version", VERSION);
        return tag;
    }
}
