package com.seasontracker.server;

import com.mojang.brigadier.arguments.LongArgumentType;
import com.seasontracker.CommonConfig;
import com.seasontracker.SeasonTracker;
import com.seasontracker.network.Network;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStartedEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

/**
 * Server-side world day counter, saved in the world.
 *
 * Cost per server tick: one long read + one compare (it returns there unless the clock moved),
 * then a little arithmetic. The save file is only marked dirty and a packet only sent when the
 * day number actually changes, which is about twice per in-game day.
 *
 *  - First run on a world starts from the world's total age (level.dat "Time": every tick the
 *    world has ever run). Unlike the day/night clock, /time set and skip-night tools can't reset it,
 *    so a 3-year-old world doesn't start at Day 1.
 *  - Keeps counting while nobody is online (as long as the server runs).
 *  - Sleeping to morning counts as one day, not two.
 *  - /time set backwards never lowers the count.
 */
public final class DayCounter {
    private static MinecraftServer server;
    private static ServerLevel overworld;
    private static DayCounterData data;
    private static boolean nightStartsNextDay;

    private static long phaseIndex(long dayTime) {
        // Counting boundary: dusk (13000) or sunrise (0).
        return Math.floorDiv(dayTime + (nightStartsNextDay ? 11000L : 0L), 24000L);
    }

    private static boolean isNight(long dayTime) {
        long t = Math.floorMod(dayTime, 24000L);
        return t >= 13000L && t < 23000L;
    }

    @SubscribeEvent
    public static void onServerStarted(ServerStartedEvent event) {
        server = event.getServer();
        overworld = server.overworld();
        data = DayCounterData.get(overworld);
        nightStartsNextDay = CommonConfig.NIGHT_STARTS_NEXT_DAY.get();

        if (!data.initialised) {
            long now = overworld.getDayTime();
            long worldAge = overworld.getGameTime();          // total ticks this world has run
            long count = worldAge / 24000L + 1L;              // world's first day = DAY 1
            if (nightStartsNextDay && isNight(now)) count++;  // already night: NIGHT N+1
            data.dayCount = count;
            data.lastDayTime = now;
            data.initialised = true;
            data.setDirty();
            SeasonTracker.LOGGER.info("[SeasonTracker] Day counter started at day {} from the world's age ({} ticks).",
                    data.dayCount, worldAge);
        }
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent event) {
        server = null;
        overworld = null;
        data = null;
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || data == null) return;

        long now = overworld.getDayTime();
        long prev = data.lastDayTime;
        if (now == prev) return;               // doDaylightCycle off, etc.
        data.lastDayTime = now;

        long add;
        if (now > prev) {
            // Normal ticking, sleeping, /time add: count the boundaries crossed.
            add = phaseIndex(now) - phaseIndex(prev);
        } else {
            // Clock set backwards: only count stepping into the next counted phase.
            boolean wasNight = isNight(prev), nowNight = isNight(now);
            add = nightStartsNextDay ? (!wasNight && nowNight ? 1 : 0) : (wasNight && !nowNight ? 1 : 0);
            data.setDirty();
        }

        if (add > 0) {
            data.dayCount += add;
            data.setDirty();
            Network.sendToAll(server, data.dayCount);
        }
    }

    @SubscribeEvent
    public static void onPlayerLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (data != null && event.getEntity() instanceof ServerPlayer player) {
            Network.sendTo(player, data.dayCount);
        }
    }

    /** /seasontracker setday <n>  (ops only) - set the number if you want a specific value. */
    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("seasontracker")
                .requires(src -> src.hasPermission(2))
                .then(Commands.literal("setday")
                        .then(Commands.argument("day", LongArgumentType.longArg(1))
                                .executes(ctx -> {
                                    if (data == null) return 0;
                                    long day = LongArgumentType.getLong(ctx, "day");
                                    data.dayCount = day;
                                    data.setDirty();
                                    Network.sendToAll(server, day);
                                    ctx.getSource().sendSuccess(() -> Component.literal("Season Tracker day set to " + day), true);
                                    return 1;
                                }))));
    }

    private DayCounter() {}
}
